% *********************************************************
% Laborator PSS: Efectele cuantizarii prin rotunjire ale produselor si
% sumelor
% g2(): sumator cu saturare la maxim 1 (in modul)
% *********************************************************

function y=g2(x)
  
  saturation = 1;
  overflow_indices = (abs(x)>=1);
  
  y=x;
  y(overflow_indices) = saturation*sign(x(overflow_indices))
end