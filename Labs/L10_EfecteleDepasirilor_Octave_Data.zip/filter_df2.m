function y = filter_df2 (b, a, x)

s1 = 0;
s2 = 0;
s3 = 0;
s4 = 0;
s4 = 0;

for n=1:length(x)
  
  s1new = x(n) - s1*a(2) - s2*a(3) - s3*a(4) - s4*a(5);
  s2new = s1;
  s3new = s2;
  s4new = s3;

  %
  y(n) = s4*b(5) + s3*b(4) + s2*b(3) + s1*b(2) + ...
          + b(1)*s1new;
  
  
  %
  s1 = s1new;
  s2 = s2new;
  s3 = s3new;
  s4 = s4new;
  
  
  
endfor

endfunction
