function  [h,mmse]=wienerfir(x,s,M)
% Calculeaza coeficientii filtrului optimal FIR rezolvind ecuatiile Wiener-Hopf
% [h,mmse]=wienerfir(x,s,M);
% Output:
%   h    = vector coloana ce contine coeficientii filtrului optimal
%   mmse =  eroarea medie patratica minima corespunzatoare filtrului optimal
% Input:
%   x = s[n]+w[n] = semnalul afectat de zgomotul de tip alb w[n]
%   s = porțiune reprezentativă de semnal util ce trebuie estimat cu ajutorul filtrului optimal
L=length(x);
rxx=xcorr(x,'biased');
rsx=xcorr(s,x,'biased');
rsxM=rsx(L:L+M-1)';
Rxx=toeplitz(rxx(L:L+M-1)');
h=(Rxx^-1)*rsxM;
mmse=var(s)-h'*rsxM;
